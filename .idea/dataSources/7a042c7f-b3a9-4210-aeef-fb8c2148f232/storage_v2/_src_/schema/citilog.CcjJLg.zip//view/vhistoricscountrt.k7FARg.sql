create view vhistoricscountrt as
select `citilog`.`historicscountrt`.`MeasureId`   AS `MeasureId`,
       `citilog`.`historicscountrt`.`Server`      AS `Server`,
       `citilog`.`historicscountrt`.`CameraId`    AS `CameraId`,
       `citilog`.`historicscountrt`.`Period`      AS `Period`,
       `citilog`.`historicscountrt`.`MeasureTime` AS `MeasureTime`
from `citilog`.`historicscountrt`;

