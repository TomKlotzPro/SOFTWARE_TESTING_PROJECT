create view vconfigcamerav8 as
select `citilog`.`configcamerav8`.`Id`       AS `Id`,
       `citilog`.`configcamerav8`.`CameraId` AS `CameraId`,
       `citilog`.`configcamerav8`.`Ip`       AS `Ip`,
       `citilog`.`configcamerav8`.`DataType` AS `DataType`,
       `citilog`.`configcamerav8`.`EqtType`  AS `EqtType`,
       `citilog`.`configcamerav8`.`Data`     AS `Data`,
       `citilog`.`configcamerav8`.`DataTime` AS `DataTime`
from `citilog`.`configcamerav8`;

