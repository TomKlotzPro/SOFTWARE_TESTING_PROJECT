create view vconfigcameralist as
select `citilog`.`configcameralist`.`Id`       AS `Id`,
       `citilog`.`configcameralist`.`CameraId` AS `CameraId`,
       `citilog`.`configcameralist`.`MaskId`   AS `MaskId`,
       `citilog`.`configcameralist`.`Mask`     AS `Mask`
from `citilog`.`configcameralist`;

