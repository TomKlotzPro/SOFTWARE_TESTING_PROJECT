create view vimages as
select `citilog`.`images`.`ImageId`       AS `ImageId`,
       `citilog`.`images`.`CameraId`      AS `CameraId`,
       `citilog`.`images`.`ReqReduction`  AS `ReqReduction`,
       `citilog`.`images`.`ReqPeriodMSec` AS `ReqPeriodMSec`,
       `citilog`.`images`.`StaticStream`  AS `StaticStream`,
       `citilog`.`images`.`ImageXml`      AS `ImageXml`,
       `citilog`.`images`.`ImageTime`     AS `ImageTime`,
       `citilog`.`images`.`ImageReqTime`  AS `ImageReqTime`
from `citilog`.`images`;

