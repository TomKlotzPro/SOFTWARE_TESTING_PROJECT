create view vhistoricscount as
select `citilog`.`historicscount`.`MeasureId`   AS `MeasureId`,
       `citilog`.`historicscount`.`Server`      AS `Server`,
       `citilog`.`historicscount`.`CameraId`    AS `CameraId`,
       `citilog`.`historicscount`.`Period`      AS `Period`,
       `citilog`.`historicscount`.`MeasureTime` AS `MeasureTime`
from `citilog`.`historicscount`;

