create view vmatrix as
select `citilog`.`matrix`.`Id`           AS `Id`,
       `citilog`.`matrix`.`WallId`       AS `WallId`,
       `citilog`.`matrix`.`MonitorId`    AS `MonitorId`,
       `citilog`.`matrix`.`MonitorState` AS `MonitorState`
from `citilog`.`matrix`;

