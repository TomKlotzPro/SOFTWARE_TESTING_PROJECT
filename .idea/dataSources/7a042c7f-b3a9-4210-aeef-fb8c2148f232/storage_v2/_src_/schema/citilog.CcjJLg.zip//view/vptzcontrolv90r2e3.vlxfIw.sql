create view vptzcontrolv90r2e3 as
select `citilog`.`ptzcontrolv90r2e3`.`CameraId`      AS `CameraId`,
       `citilog`.`ptzcontrolv90r2e3`.`CurrentPreset` AS `CurrentPreset`,
       `citilog`.`ptzcontrolv90r2e3`.`Protocol`      AS `Protocol`,
       `citilog`.`ptzcontrolv90r2e3`.`Pan`           AS `Pan`,
       `citilog`.`ptzcontrolv90r2e3`.`Tilt`          AS `Tilt`,
       `citilog`.`ptzcontrolv90r2e3`.`Zoom`          AS `Zoom`,
       `citilog`.`ptzcontrolv90r2e3`.`Focus`         AS `Focus`,
       `citilog`.`ptzcontrolv90r2e3`.`Iris`          AS `Iris`,
       `citilog`.`ptzcontrolv90r2e3`.`Telemetrics`   AS `Telemetrics`,
       `citilog`.`ptzcontrolv90r2e3`.`FocusMode`     AS `FocusMode`,
       `citilog`.`ptzcontrolv90r2e3`.`CameraModel`   AS `CameraModel`,
       `citilog`.`ptzcontrolv90r2e3`.`PresetList`    AS `PresetList`,
       `citilog`.`ptzcontrolv90r2e3`.`AidMode`       AS `AidMode`
from `citilog`.`ptzcontrolv90r2e3`;

