create view vstreams as
select `citilog`.`streams`.`Id`         AS `Id`,
       `citilog`.`streams`.`StreamName` AS `StreamName`,
       `citilog`.`streams`.`CameraId`   AS `CameraId`,
       `citilog`.`streams`.`StreamType` AS `StreamType`,
       `citilog`.`streams`.`EqtName`    AS `EqtName`,
       `citilog`.`streams`.`Settings`   AS `Settings`
from `citilog`.`streams`;

