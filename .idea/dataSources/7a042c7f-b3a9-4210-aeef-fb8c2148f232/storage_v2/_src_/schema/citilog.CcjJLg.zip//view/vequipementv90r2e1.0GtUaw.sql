create view vequipementv90r2e1 as
select `citilog`.`equipementv90r2e1`.`Id`           AS `Id`,
       `citilog`.`equipementv90r2e1`.`Ip`           AS `Ip`,
       `citilog`.`equipementv90r2e1`.`RemoteIp`     AS `RemoteIp`,
       `citilog`.`equipementv90r2e1`.`MacAddress`   AS `MacAddress`,
       `citilog`.`equipementv90r2e1`.`Type`         AS `Type`,
       `citilog`.`equipementv90r2e1`.`Name`         AS `Name`,
       `citilog`.`equipementv90r2e1`.`Settings`     AS `Settings`,
       `citilog`.`equipementv90r2e1`.`ConfigEqt`    AS `ConfigEqt`,
       `citilog`.`equipementv90r2e1`.`ConfigSrv`    AS `ConfigSrv`,
       `citilog`.`equipementv90r2e1`.`NetWorkNames` AS `NetWorkNames`,
       `citilog`.`equipementv90r2e1`.`PingDateTime` AS `PingDateTime`,
       `citilog`.`equipementv90r2e1`.`State`        AS `State`,
       `citilog`.`equipementv90r2e1`.`StateInfo`    AS `StateInfo`
from `citilog`.`equipementv90r2e1`;

