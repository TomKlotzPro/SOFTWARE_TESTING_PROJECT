create view vsequencesv80r2e1 as
select `citilog`.`sequencesv80r2e1`.`Id`            AS `Id`,
       `citilog`.`sequencesv80r2e1`.`Completed`     AS `Completed`,
       `citilog`.`sequencesv80r2e1`.`CameraId`      AS `CameraId`,
       `citilog`.`sequencesv80r2e1`.`ComputerIp`    AS `ComputerIp`,
       `citilog`.`sequencesv80r2e1`.`ComputerName`  AS `ComputerName`,
       `citilog`.`sequencesv80r2e1`.`FilteredState` AS `FilteredState`,
       `citilog`.`sequencesv80r2e1`.`FilterName`    AS `FilterName`,
       `citilog`.`sequencesv80r2e1`.`SeqName`       AS `SeqName`,
       `citilog`.`sequencesv80r2e1`.`SeqPath`       AS `SeqPath`,
       `citilog`.`sequencesv80r2e1`.`Server`        AS `Server`,
       `citilog`.`sequencesv80r2e1`.`SeqSyncName`   AS `SeqSyncName`,
       `citilog`.`sequencesv80r2e1`.`AckType`       AS `AckType`,
       `citilog`.`sequencesv80r2e1`.`AckComputer`   AS `AckComputer`,
       `citilog`.`sequencesv80r2e1`.`Comment`       AS `Comment`,
       `citilog`.`sequencesv80r2e1`.`Note`          AS `Note`
from `citilog`.`sequencesv80r2e1`;

